
import streamlit as st
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime, timezone
from core import preprocess as pp
from core import peaks as pk
from core import features as ft
from core.schemas import PreprocessConfig
from core.io import save_jsonl
from app.session_io import make_session_dir, write_session_header, write_cell_map, append_labels, append_peaks, now_utc_iso

st.set_page_config(page_title="OPCAL MLT", layout="wide")
st.title("OPCAL Manual Labeling Tool")

with st.sidebar:
    st.header("Session")
    annotator = st.text_input("Annotator ID", value=st.session_state.get("annotator", ""))
    save_dir = st.text_input("Save directory", value=st.session_state.get("save_dir", str(Path.home() / "OPCAL_LABELS")))
    start_session = st.button("Start / Update Session")
    st.markdown('---')
    st.header("Signal settings")
    fs_hz = st.number_input("Sampling rate (Hz)", min_value=0.1, value=10.0, step=0.1)
    smooth = st.checkbox("Apply Savitzky–Golay smoothing", value=True)
    window = st.slider("Smooth window", 5, 101, 31, step=2)
    poly = st.slider("Smooth polyorder", 1, 5, 3)
    baseline_method = st.selectbox("Baseline method", ["rolling_median", "percentile (25)"])
    window_s = st.slider("Rolling median window (s)", 5, 60, 20)
    k = st.slider("SD threshold k", 1.0, 6.0, 3.0, step=0.5)
    stim_time_s = st.number_input("Stimulus time (s)", min_value=0.0, value=5.0, help="Time when stimulation starts; used for dual-SD shading")

uploaded = st.file_uploader("Upload traces CSV (rows=time, cols=cells) or NPZ", type=["csv", "npz"])

s = st.session_state
s.setdefault("labels", [])
s.setdefault("current_cell", 0)
s.setdefault("traces", None)
s.setdefault("cell_ids", [])
s.setdefault("recording_id", "rec_001")
s.setdefault("session_dir", None)
s.setdefault("annotator", annotator)
s.setdefault("save_dir", save_dir)

if uploaded:
    suffix = Path(uploaded.name).suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(uploaded)
        s.traces = df.values
        s.cell_ids = list(df.columns.astype(str))
    else:
        npz = np.load(uploaded)
        s.traces = npz["traces"]
        s.cell_ids = [f"cell_{i:05d}" for i in range(s.traces.shape[1])]
        if "recording_id" in npz:
            s.recording_id = str(npz["recording_id"])
    st.success(f"Loaded traces: shape {s.traces.shape}")

if start_session and s.traces is not None:
    s.annotator = annotator.strip() or "anon"
    s.save_dir = save_dir.strip() or str(Path.home() / "OPCAL_LABELS")
    base_dir = Path(s.save_dir)
    s.session_dir = make_session_dir(base_dir, s.recording_id, s.annotator)
    write_session_header(
        s.session_dir,
        {
            "session_id": Path(s.session_dir).name,
            "recording_id": s.recording_id,
            "annotator_id": s.annotator,
            "fs_hz": fs_hz,
            "started_utc": now_utc_iso(),
            "app_version": "mlt-0.2.0",
            "source_path": uploaded.name if uploaded else "",
            "source_sha256": "",
        },
    )
    if not s.cell_ids:
        s.cell_ids = [f"cell_{i:05d}" for i in range(s.traces.shape[1])]
    write_cell_map(
        s.session_dir, [{"cell_index": i, "cell_id": s.cell_ids[i]} for i in range(len(s.cell_ids))]
    )
    st.success(f"Session folder: {s.session_dir}")

if s.traces is not None:
    T, N = s.traces.shape
    left, mid, right = st.columns([1,2,1], gap="large")
    with left:
        st.subheader("Cells")
        idx = st.number_input("Cell index", 0, N-1, s.current_cell, step=1)
        s.current_cell = idx
        st.write(f"Progress: {len(s.labels)} / {N} labeled")
        colA, colB = st.columns(2)
        if colA.button("Prev"): s.current_cell = max(0, s.current_cell - 1)
        if colB.button("Next"): s.current_cell = min(N-1, s.current_cell + 1)

    x = s.traces[:, s.current_cell].astype(float)
    x_s = pp.smooth_signal(x, window=window, polyorder=poly) if smooth else x
    base = pp.baseline_rolling_median(x_s, fs_hz, window_s=window_s) if baseline_method.startswith("rolling") else pp.baseline_percentile(x_s, q=25.0)

    thr_pre, thr_post, sd_pre, sd_post, stim_idx = pp.dual_sd_thresholds(x_s, base, fs_hz, stim_time_s, k=k)
    thr = np.concatenate([thr_pre, thr_post])
    peaks = pk.detect_peaks(x_s, thr, fs_hz, min_distance_s=1.0)

    with mid:
        st.subheader(f"Cell {s.cell_ids[s.current_cell]}")
        import plotly.graph_objects as go
        t = np.arange(x.size)/fs_hz
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=t, y=x, name="raw", line=dict(width=1)))
        if smooth:
            fig.add_trace(go.Scatter(x=t, y=x_s, name="smoothed", line=dict(width=2)))
        fig.add_trace(go.Scatter(x=t, y=base, name="baseline", line=dict(width=1, dash="dash")))
        # Shading envelopes
        if stim_idx > 1:
            fig.add_shape(type="rect",
                          x0=t[0], x1=t[stim_idx-1], y0=base[:stim_idx].min(), y1=(thr_pre).max(),
                          fillcolor="rgba(0,200,0,0.15)", line=dict(width=0), layer="below")
        fig.add_shape(type="rect",
                      x0=t[stim_idx], x1=t[-1], y0=base[stim_idx:].min(), y1=(thr_post).max(),
                      fillcolor="rgba(200,0,0,0.15)", line=dict(width=0), layer="below")
        fig.add_trace(go.Scatter(x=t[:stim_idx], y=thr_pre, name=f"thr pre ({k}·SD)", line=dict(width=1)))
        fig.add_trace(go.Scatter(x=t[stim_idx:], y=thr_post, name=f"thr post ({k}·SD)", line=dict(width=1)))
        fig.add_trace(go.Scatter(x=t[peaks], y=x_s[peaks], mode="markers", name="peaks"))
        fig.update_layout(height=520, hovermode="x unified")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Label")
        label = st.radio("Class", ["High-flat", "High-oscillatory", "Oscillatory", "Low-activity"], index=2)
        uncertain = st.checkbox("Uncertain", value=False)
        notes = st.text_area("Notes", placeholder="Optional free text")
        if st.button("Save label (CSV)"):
            feats = ft.basic_features(x_s, thr, fs_hz, peaks)
            saved_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
            lab_row = {
                "session_id": Path(s.session_dir).name if s.session_dir else "nosession",
                "recording_id": s.recording_id,
                "annotator_id": s.annotator if s.session_dir else "",
                "saved_utc": saved_utc,
                "cell_index": int(s.current_cell),
                "cell_id": str(s.cell_ids[s.current_cell]),
                "label": label,
                "is_uncertain": bool(uncertain),
                "notes": notes,
                "filter_type": "savgol" if smooth else "none",
                "filter_window": int(window) if smooth else 0,
                "filter_polyorder": int(poly) if smooth else 0,
                "baseline_method": "rolling_median" if baseline_method.startswith("rolling") else "percentile",
                "baseline_window_s_or_q": float(window_s) if baseline_method.startswith("rolling") else 25.0,
                "sd_method": "MAD",
                "threshold_k": float(k),
                "mean": float(feats["mean"]),
                "std": float(feats["std"]),
                "rms": float(feats["rms"]),
                "frac_above_thr": float(feats["frac_above_thr"]),
                "peaks_per_min": float(feats["peaks_per_min"]),
                "version": "mlt-0.2.0",
            }
            if s.session_dir:
                append_labels(Path(s.session_dir), lab_row)
                peak_rows = [{
                    "session_id": Path(s.session_dir).name,
                    "recording_id": s.recording_id,
                    "cell_index": int(s.current_cell),
                    "peak_idx": int(p),
                    "peak_time_s": float(p)/fs_hz,
                    "peak_value": float(x_s[p]),
                } for p in peaks]
                append_peaks(Path(s.session_dir), peak_rows)
                st.success(f"Saved → {Path(s.session_dir) / 'labels.csv'}")
            else:
                st.warning("Start a session (Annotator & Save dir) to save CSVs.")
        if st.button("Export JSONL (legacy)"):
            out = Path("labels.jsonl")
            save_jsonl(s.labels, out)
            st.success(f"Exported {len(s.labels)} labels to {out.resolve()}")
else:
    st.info("Upload traces to begin.")
